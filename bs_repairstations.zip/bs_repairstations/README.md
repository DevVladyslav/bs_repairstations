# bs-vehiclesystem

# DO NOT RESELL OR REREALASE (Made originally for DreamlessRP Made by Vladyslav#7497)

# REQUIRED

[ESX](https://forum.fivem.net/t/release-esx-base/39881)

[mythic_notify](https://github.com/mythicrp/mythic_notify)

[mythic_progbar](https://github.com/mythicrp/mythic_progbar)

DISCORD: httpsL//discord.gg/agwmsrN