ESX = nil 

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('bs_repairstations:billing')
AddEventHandler('bs_repairstations:billing', function()
	local price = Config.price
    local src = source
	local xPlayer = ESX.GetPlayerFromId(src)
			xPlayer.removeBank(price)
end)

AddEventHandler('chatMessage', function(source, _, message)
	local msg = string.lower(message)
	local identifier = GetPlayerIdentifiers(source)[1]
	if msg == "/repair" then
		CancelEvent()
			TriggerClientEvent('bs_repairstations:repair', source)
		else
				TriggerClientEvent('bs_repairstations:repair', source)
			end
		end)