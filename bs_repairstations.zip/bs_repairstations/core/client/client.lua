ESX             = nil

local healthBodyLast = 1000.0
local healthEngineLast = 1000.0
local healthPetrolTankLast = 1000.0

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local function checkWhitelist(id)
    for key, value in pairs(RepairWhitelist) do
        if id == value then
            return true
        end
    end 
    return false
end

local function IsNearMechanic()
    local ped = GetPlayerPed(-1)
    local pedLocation = GetEntityCoords(ped, 0)
    for _, item in pairs(repair.mechanics) do
        local distance = GetDistanceBetweenCoords(item.x, item.y, item.z,  pedLocation["x"], pedLocation["y"], pedLocation["z"], true)
        if distance <= item.r then
            return true
        end
    end
end

local function isPedDrivingAVehicle()
    local ped = GetPlayerPed(-1)
    vehicle = GetVehiclePedIsIn(ped, false)
    if IsPedInAnyVehicle(ped, false) then
        if GetPedInVehicleSeat(vehicle, -1) == ped then
            local class = GetVehicleClass(vehicle)
            if class ~= 15 and class ~= 16 and class ~=21 and class ~=13 then
                return true
            end
        end
    end
    return false
end

RegisterNetEvent('bs_repairstations:repair')
AddEventHandler('bs_repairstations:repair', function()
    if isPedDrivingAVehicle() then
        local ped = PlayerPedId(-1)
        local text_string = Config.text
        vehicle = GetVehiclePedIsIn(ped, false)
        if IsNearMechanic() then
            SetVehicleUndriveable(vehicle,false)
            SetVehicleFixed(vehicle)
            healthBodyLast=1000.0
            healthEngineLast=1000.0
            healthPetrolTankLast=1000.0
            SetVehicleDoorOpen(vehicle, 4, false, true)
            SetVehicleEngineOn(vehicle, true, false )
            exports['progressBars']:startUI(10000, "Mechanic is looking at your vehicle...")
            FreezeEntityPosition(vehicle, true)
            Citizen.Wait(10000)
            FreezeEntityPosition(vehicle, false)
            SetVehicleDoorShut(vehicle, 4, true)
            TriggerServerEvent('bs_repairstations:billing')
            exports['mythic_notify']:SendAlert('type', (text_string))
            return
        end
    end
end)

-- Display blips on map
Citizen.CreateThread(function()
        for _, item in pairs(repair.mechanics) do
            item.blip = AddBlipForCoord(item.x, item.y, item.z)
            SetBlipSprite(item.blip, item.id)
            SetBlipAsShortRange(item.blip, true)
            SetBlipScale  (item.blip, 0.7)
            SetBlipColour (item.blip, 40)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(item.name)
            EndTextCommandSetBlipName(item.blip)
        end
    end)